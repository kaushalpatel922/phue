# Published under the MIT license - See LICENSE file for more detail
#
# This is a basic test file which just tests that things import, which
# means that this is even vaguely python code.

import testtools

import phue  # noqa


class TestImport(testtools.TestCase):

    def test_import_works(self):
        pass
